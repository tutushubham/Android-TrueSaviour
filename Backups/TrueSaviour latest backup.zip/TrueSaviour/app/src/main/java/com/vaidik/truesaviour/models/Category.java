package com.vaidik.truesaviour.models;

public class Category {

    public String name, desc, thumb;

    public Category(String name, String desc, String thumb) {
        this.name = name;
        this.desc = desc;
        this.thumb = thumb;
    }

}
