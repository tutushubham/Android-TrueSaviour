package com.vaidik.truesaviour.activites;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.vaidik.truesaviour.R;

public class TSbot extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tsbot);
    }
}
